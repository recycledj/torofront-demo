import React, { Fragment, useState, useEffect } from 'react';
import { Grid, Typography, ButtonBase, makeStyles, Paper } from '@material-ui/core';
import axios from 'axios';

const useStyles = makeStyles((theme) => ({
    root: {
        flexGrow: 1,
    },
    paper: {
        padding: theme.spacing(2),
        margin: 'auto',
        maxWidth: 800,
    },
    image: {
        width: 128,
        height: 128,
    },
    img: {
        margin: 'auto',
        display: 'block',
        maxWidth: '100%',
        maxHeight: '100%',
    },
    container: {
        maxWidth: '100%'
    },
    spacing: {
        marginBottom: 20,
        marginTop: 20
    }
}));

function Steers() {
    const [novillos, setNovillos] = useState([]);

    useEffect(() => {
        const getSteers = async () => {
            const { data } = await axios({
                method: "GET",
                url: "http://localhost:3005/api/won"
            });

            if (data) setNovillos(data[0]);
        }
        getSteers();
    }, [])
    const classes = useStyles();
    return (
        <Fragment>
            <Grid container className={classes.spacing}>
                <Grid item>
                    <Typography component="h1" variant="h3" align="center">
                        Novillos
                    </Typography>
                </Grid>
            </Grid>
            <Grid container
                direction="row"
                justify="center"
                alignItems="flex-start"
                spacing={4}
                className={classes.container}
            >
                {novillos.map((row) => (
                    <Grid item xs={3} md={3}>
                        <Paper className={classes.paper}>
                            <Grid container spacing={2}>
                                <Grid item>
                                    <ButtonBase className={classes.image}>
                                        <img className={classes.img} alt={row.codeWon} src={"http://localhost:3005/" + row.photo} />
                                    </ButtonBase>
                                </Grid>
                                <Grid item xs={12} sm container>
                                    <Grid item xs container direction="column" spacing={2}>
                                        <Grid item xs>
                                            <Typography gutterBottom variant="subtitle1">
                                                Novillo: {row.codeWon}
                                            </Typography>
                                            <Typography variant="body2" gutterBottom>
                                                Peso: {row.weight} kg
                                             </Typography>
                                            <Typography variant="body2">
                                                Edad: {row.age}
                                            </Typography>
                                            <Typography variant="body2" color="textSecondary">
                                                ID: {row.id}
                                            </Typography>
                                        </Grid>
                                        <Grid item>
                                            <Typography variant="body2" style={{ cursor: 'pointer' }}>
                                                Editar
                                            </Typography>
                                        </Grid>
                                    </Grid>
                                    <Grid item>
                                        <Typography variant="subtitle1">$19.00</Typography>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Paper>
                    </Grid>
                ))}
            </Grid>
        </Fragment>
    )
}

export default Steers;